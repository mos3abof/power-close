<?php
header("Location: https://addons.mozilla.org/firefox/addon/firefox-power-close/");
die();

